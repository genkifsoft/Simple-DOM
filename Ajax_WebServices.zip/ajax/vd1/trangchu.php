<h1>Trang chu</h1>
<a href="gioithieu.php">Gioi thieu</a>


<iframe width="560" height="315" src="https://www.youtube.com/embed/z5JLkgk0Cok" frameborder="0" allowfullscreen></iframe>
