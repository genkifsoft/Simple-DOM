<h1>Gioi thieu</h1>
<a href="trangchu.php">Trang chu</a>


<iframe width="560" height="315" src="https://www.youtube.com/embed/z5JLkgk0Cok" frameborder="0" allowfullscreen></iframe>
